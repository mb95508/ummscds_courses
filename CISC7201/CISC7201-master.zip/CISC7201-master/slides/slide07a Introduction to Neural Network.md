Please find the slide [here](https://www.slideshare.net/databricks/introduction-to-neural-networks-122033415?from_action=save)
